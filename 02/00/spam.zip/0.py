import zipfile

data = b'Insert Data Here'
with zipfile.ZipFile('spam.zip', 'w') as f:
#    f.write(data)
    f.write('0.py')

with zipfile.ZipFile('spam.zip') as myzip:
    with myzip.open('0.py') as myfile:
        print(myfile.read())

